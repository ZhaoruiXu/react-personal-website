export default function Footer() {
  return (
    <footer>
      <p>
        designed and built by zhaorui xu <span>&copy;</span>
        2022
      </p>
    </footer>
  );
}
