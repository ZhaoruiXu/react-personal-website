<?php  
function twentytwentytwo_child_enqueues() {

  // Enqueue Parent Theme CSS
  wp_enqueue_style( 
  'parent-style',
   get_template_directory_uri() .'/style.css' // Returns the URL to the parent theme folder. (Or the current theme folder if no child theme is being used
  );

};
add_action( 'wp_enqueue_scripts', 'twentytwentytwo_child_enqueues');

/**
 * Customizer additions.
 */
require get_stylesheet_directory() . '/inc/cpt-taxonomy.php';