<?php

// ----------------------------------------------------------------
// -------------- Register Custom Post Type (CPT) -----------------
// ----------------------------------------------------------------

function fwd_register_custom_post_types() {

// ----------------------------------------------------------------

    // Register Projects CPT
    $labels = array(
    'name'               => _x( 'Projects', 'post type general name'  ),
    'singular_name'      => _x( 'Project', 'post type singular name'  ),
    'menu_name'          => _x( 'Projects', 'admin menu'  ),
    'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
    'add_new'            => _x( 'Add New', 'Project' ),
    'add_new_item'       => __( 'Add New Project' ),
    'new_item'           => __( 'New Project' ),
    'edit_item'          => __( 'Edit Project' ),
    'view_item'          => __( 'View Project'  ),
    'all_items'          => __( 'All Project' ),
    'search_items'       => __( 'Search Projects' ),
    'parent_item_colon'  => __( 'Parent Projects:' ),
    'not_found'          => __( 'No Projects found.' ),
    'not_found_in_trash' => __( 'No Projects found in Trash.' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'show_in_rest'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'projects' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 7,
        'menu_icon'          => 'dashicons-format-aside',
        'supports'           => array( 'title', 'page-attributes' ),
        // Prevent moving, inserting, deleting blocks
        'template_lock' => 'all',
    );

    register_post_type( 'fwd-project', $args );

}
add_action( 'init', 'fwd_register_custom_post_types' );


// ----------------------------------------------------------------
// ---------------------- Register Taxonomies ---------------------
// ----------------------------------------------------------------

function fwd_register_taxonomies() {
    // Add Project Category taxonomy
    $labels = array(
        'name'              => _x( 'Project Categories', 'taxonomy general name' ),
        'singular_name'     => _x( 'Project Category', 'taxonomy singular name' ),
        'search_items'      => __( 'Search Project Categories' ),
        'all_items'         => __( 'All Project Category' ),
        'parent_item'       => __( 'Parent Project Category' ),
        'parent_item_colon' => __( 'Parent Project Category:' ),
        'edit_item'         => __( 'Edit Project Category' ),
        'view_item'         => __( 'Vview Project Category' ),
        'update_item'       => __( 'Update Project Category' ),
        'add_new_item'      => __( 'Add New Project Category' ),
        'new_item_name'     => __( 'New Project Category Name' ),
        'menu_name'         => __( 'Project Category' ),
        // No block editor or template is used. Instead using Advanced Custom Fields (ACF)
    );
    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_in_menu'      => true,
        'show_in_nav_menu'  => true,
        'show_in_rest'      => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'project-categories' ),
    );
    register_taxonomy( 'fwd-project-category', array( 'fwd-project' ), $args );
}
add_action( 'init', 'fwd_register_taxonomies');

// Flushes permalinks when switching themes
function fwd_rewrite_flush() {
    fwd_register_custom_post_types();
    fwd_register_taxonomies();
    flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'fwd_rewrite_flush' );